public class Cliente extends Pessoas {

    public Cliente(String nome, String fone, String email) {
        super(nome,fone,email);
    }

    @Override
    void consultar() {

    }

    @Override
    void pegar() {

    }
    public void cadastrar(){

    }
    public void efetuarPedidoCliente(){

    }

    public void efetuarPagamento(){

    }
}