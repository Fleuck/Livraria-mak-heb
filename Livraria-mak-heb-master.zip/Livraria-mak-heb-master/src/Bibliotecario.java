abstract class Bibliotecario extends Funcionarios{
    public Bibliotecario(String nome, String fone, String email, double salario, String cargo, int id) {
        super(nome, fone, email, salario, cargo, id);
    }
}
