abstract class Comprador extends Funcionarios{
    public Comprador(String nome, String fone, String email, double salario, String cargo, int id) {
        super(nome, fone, email, salario, cargo, id);
    }
}
