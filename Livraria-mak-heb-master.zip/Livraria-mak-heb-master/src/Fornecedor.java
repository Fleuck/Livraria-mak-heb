public class Fornecedor extends Pessoas{
    public Fornecedor(String nome, String fone, String email) {
        super(nome, fone, email);
    }

    @Override
    void consultar() {

    }

    @Override
    void pegar() {

    }
}
