import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        while(true){
            System.out.println("Seja bem vindo ao sistema de gerenciamento da biblioteca da Mak Heb");

            System.out.println("---------------------------------------------------------------------");
            System.out.println("Pressione: ");
            System.out.println("1.Acessar informacoes sobre os fornecedores ");
            System.out.println("2.Acessar estoque da biblioteca");
            System.out.println("3.Acessar gerenciamento sobre funcionarios");
            System.out.println("---------------------------------------------------------------------");
        }
    }
}