public abstract class vendedora extends Funcionarios {
    public vendedora(String nome, String endereco, String Sobrenome, int cpf, String cargo, double salario, double id) {
        super(nome, endereco, Sobrenome, cpf, cargo, salario, id);
    }
}