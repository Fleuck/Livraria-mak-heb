public class CaixaPgto extends TelaComprador {
    private  float CaixaValor;

    public float getCaixaValor() {
        return CaixaValor;
    }

    public void setCaixaValor(float caixaValor) {
        CaixaValor = caixaValor;
    }

    public double valorPago(double valor){
            
        setCaixaValor(getCaixaValor() - valor);
        return getCaixaValor();
    }

    private void setCaixaValor(double RetornoValor) {
    }


}
